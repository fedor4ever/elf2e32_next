// Copyright (c) 2024 Stryzhniou Fiodar
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of the License "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Overview:

// Tests it is possible to retrieve the 0th ordinal from dll
// that are marked as having named symbol export data.
// API Information:
// RProcess, RLibrary
// Details:
// -  Test reading 0th ordinal from a dll which has a E32EpocExpSymInfoHdr
// struct at the 0th ordinal and verify the contents of the header
// That DLL represent freezed interface evolution for STDDLL - one function removed.
// That DLL can't be builded due bag in elf2e32
// Platforms/Drives/Compatibility:
// All
// Assumptions/Requirement/Pre-requisites:
// Failures and causes:
// Base Port information:
//
//

#include <e32test.h>
#include <e32panic.h>
#include <f32image.h>

RTest test(_L("DLL with mised symbols"));
_LIT(KMissed,"t_oemissed.dll");

// This is defined as LOCAL_D(static) to ensure that tools allow static symbol in stdexe/dlls
// as this was not always the case.
LOCAL_D void VerifyHdr(E32EpocExpSymInfoHdr& aExpectedHdr, E32EpocExpSymInfoHdr &aReadHdr)
 {
 test(aExpectedHdr.iSize == aReadHdr.iSize);
 test(aExpectedHdr.iFlags == aReadHdr.iFlags);
 test(aExpectedHdr.iSymCount == aReadHdr.iSymCount);
 test(aExpectedHdr.iSymbolTblOffset == aReadHdr.iSymbolTblOffset);
 test(aExpectedHdr.iStringTableSz == aReadHdr.iStringTableSz);
 test(aExpectedHdr.iStringTableOffset == aReadHdr.iStringTableOffset);
 test(aExpectedHdr.iDllCount == aReadHdr.iDllCount);
 test(aExpectedHdr.iDepDllZeroOrdTableOffset == aReadHdr.iDepDllZeroOrdTableOffset);
 }

TInt E32Main()
 {
 test.Title();
 test.Start(_L("Test retrieving 0th ordinal and therefore named symbol export data: N"));

 E32EpocExpSymInfoHdr tmpHdr;
 E32EpocExpSymInfoHdr *readHdr;
 RLibrary library;

 // The values for the header of the dll with a 0th ordinal
 tmpHdr.iSize = 0x54;
 tmpHdr.iFlags = 0x0;
 tmpHdr.iSymCount = 4;
 tmpHdr.iSymbolTblOffset = 0x1c;
 tmpHdr.iStringTableSz = 0x20;
 tmpHdr.iStringTableOffset = 0x34;
 tmpHdr.iDllCount = 0;
 tmpHdr.iDepDllZeroOrdTableOffset = 0x54;
 test(library.Load(KMissed) == KErrNone);
 test.Next(_L("Attempt to retrieve named symbol data from _N.dll"));
 readHdr = (E32EpocExpSymInfoHdr*)library.Lookup(0);
 test(readHdr!=NULL);
 test.Next(_L("Verify export data of _N.dll at the 0th ordinal is that expected"));
 VerifyHdr(tmpHdr, *readHdr);
 library.Close();

 test.End();
 User::After(5000000); // 5 sec
 return KErrNone;
 }
