/*
 ============================================================================
 Name		: stddll_example.cpp
 Author	  : Stryzhniou Fiodar
 Copyright   : 2024 Stryzhniou Fiodar
 Description : Cstddll_example DLL source
 ============================================================================
 */

//  Include Files
#include <e32def.h>

//  Member Functions
#if 0
IMPORT_C void Func();
IMPORT_C void Func1();
IMPORT_C TInt Func2();
IMPORT_C TUint16 Func3();
#endif


// Removed obsolete function
//EXPORT_C void Crash_me111(){}

EXPORT_C void Func(){}
EXPORT_C void Func1(){}
EXPORT_C TInt Func2(){ return 0;}
EXPORT_C TUint16 Func3(){ return 0;}
